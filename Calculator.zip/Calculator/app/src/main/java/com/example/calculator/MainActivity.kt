    import android.widget.Toast
    import androidx.appcompat.app.AppCompatActivity
    import android.os.Bundle
    import android.view.View
    import android.widget.Button
    import android.widget.TextView
    import com.example.calculator.R

    class MainActivity : AppCompatActivity() {
        private lateinit var number1TextView: TextView
        private lateinit var number2TextView: TextView
        private lateinit var resultTextView: TextView

        private var num1 = 0.0
        private var num2 = 0.0
        private var operator = ""

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            number1TextView = findViewById(R.id.number1TextView)
            number2TextView = findViewById(R.id.number2TextView)
            resultTextView = findViewById(R.id.resultTextView)

            val clearButton = findViewById<Button>(R.id.buttonClear)
            val plusButton = findViewById<Button>(R.id.buttonPlus)
            val minusButton = findViewById<Button>(R.id.buttonMinus)
            val multiplyButton = findViewById<Button>(R.id.buttonMultiply)
            val divideButton = findViewById<Button>(R.id.buttonDivide)

            clearButton.setOnClickListener { clear() }
            plusButton.setOnClickListener { setOperator("+") }
            minusButton.setOnClickListener { setOperator("-") }
            multiplyButton.setOnClickListener { setOperator("*") }
            divideButton.setOnClickListener { setOperator("/") }
        }

        private fun clear() {
            num1 = 0.0
            num2 = 0.0
            operator = ""
            number1TextView.text = "Bilangan 1"
            number2TextView.text = "Bilangan 2"
            resultTextView.text = "Hasil"
        }

        private fun setOperator(op: String) {
            operator = op
            number1TextView.text = "Masukkan Bilangan 1"
            number2TextView.text = "Masukkan Bilangan 2"
            resultTextView.text = "Hasil"
        }

        fun onNumberButtonClick(view: View) {
            val button = view as Button
            val number = button.text.toString().toDouble()

            if (operator.isEmpty()) {
                num1 = number
                number1TextView.text = "Bilangan 1: $num1"
            } else {
                num2 = number
                number2TextView.text = "Bilangan 2: $num2"
            }
        }

        fun onEqualsButtonClick(view: View) {
            var result = 0.0

            when (operator) {
                "+" -> result = num1 + num2
                "-" -> result = num1 - num2
                "*" -> result = num1 * num2
                "/" -> {
                    if (num2 != 0.0) {
                        result = num1 / num2
                    } else {
                        val message = "Pembagian oleh 0 tidak valid"
                        resultTextView.text = message
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                        return
                    }
                }
            }

            val message = "Hasil: $result"
            resultTextView.text = message
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }





